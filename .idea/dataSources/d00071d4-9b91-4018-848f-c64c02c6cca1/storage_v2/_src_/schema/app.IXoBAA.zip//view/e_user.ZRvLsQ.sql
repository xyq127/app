create view e_user as
select `app`.`admin`.`admin_id` AS `id`, `app`.`admin`.`admin_password` AS `password`, 'ROLE_ADMIN' AS `role`
from `app`.`admin`;

